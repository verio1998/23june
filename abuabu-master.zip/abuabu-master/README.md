# abuabu
script auto claim voucher + setpin
